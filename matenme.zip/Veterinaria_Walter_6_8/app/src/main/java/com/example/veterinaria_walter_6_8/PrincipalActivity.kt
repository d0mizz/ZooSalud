package com.example.veterinaria_walter_6_8

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.PopupWindow
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.example.veterinaria_walter_6_8.databinding.PrincipalBinding
import com.example.veterinaria_walter_6_8.databinding.DespegableInfoBinding

class PrincipalActivity : AppCompatActivity() {

    private lateinit var binding: PrincipalBinding
    private lateinit var popupWindow: PopupWindow

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = PrincipalBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupBasicComponents()
    }

    private fun setupBasicComponents() {
        // 1. Slider (ViewPager2) - Opcional si lo necesitas
        setupSlider()

        // 2. Botón para agregar mascota
        binding.btnAgregarMascota.setOnClickListener {
            startActivity(Intent(this, AgregarMascotaActivity::class.java))
        }

        // 3. Botón desplegable
        binding.btnDesplegable.setOnClickListener { view ->
            showInfoPopup(view)
        }
    }

    private fun setupSlider() {
        val sliderImages = listOf(
            R.drawable.slide1,  // Reemplaza con tus imágenes
            R.drawable.slide2,
            R.drawable.slide3
        )

        binding.viewPagerSlider.adapter = SliderAdapter(sliderImages)
        binding.viewPagerSlider.orientation = ViewPager2.ORIENTATION_HORIZONTAL
    }

    private fun showInfoPopup(anchorView: View) {
        val popupBinding = DespegableInfoBinding.inflate(LayoutInflater.from(this))

        popupWindow = PopupWindow(
            popupBinding.root,
            resources.getDimensionPixelSize(R.dimen.popup_width),
            resources.getDimensionPixelSize(R.dimen.popup_height),
            true
        ).apply {
            elevation = 10f
            showAsDropDown(anchorView)
        }

        popupBinding.btnVerDetalle.setOnClickListener {
            startActivity(Intent(this@PrincipalActivity, InfoMascotaActivity::class.java))
            popupWindow.dismiss()
        }
    }

    // Clase SliderAdapter interna (simplificada)
    private inner class SliderAdapter(private val images: List<Int>) :
        RecyclerView.Adapter<SliderAdapter.SliderViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SliderViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_slide, parent, false)
            return SliderViewHolder(view)
        }

        override fun onBindViewHolder(holder: SliderViewHolder, position: Int) {
            holder.bind(images[position])
        }

        override fun getItemCount() = images.size

        inner class SliderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val imageView: ImageView = itemView.findViewById(R.id.img_slide)

            fun bind(imageRes: Int) {
                imageView.setImageResource(imageRes)
            }
        }
    }
}