import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.veterinaria_walter_6_8.SiguienteActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Inicia directamente la primera pantalla (siguiente.xml)
        val intent = Intent(this, SiguienteActivity::class.java)
        startActivity(intent)
        finish() // Opcional: evita que el usuario regrese aquí con el botón "back"
    }
}