package com.example.veterinaria_walter_6_8  // Asegúrate de que coincida con tu paquete

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.veterinaria_walter_6_8.databinding.Siguiente2Binding  // Import ajustado

class Siguiente2Activity : AppCompatActivity() {
    private lateinit var binding: Siguiente2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = Siguiente2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSiguiente.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}