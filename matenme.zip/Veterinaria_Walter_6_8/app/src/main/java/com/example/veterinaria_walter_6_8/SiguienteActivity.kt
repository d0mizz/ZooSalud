package com.example.veterinaria_walter_6_8

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.veterinaria_walter_6_8.databinding.SiguienteBinding

class SiguienteActivity : AppCompatActivity() {
    private lateinit var binding: SiguienteBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = SiguienteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSiguiente.setOnClickListener {
            val intent = Intent(this, Siguiente2Activity::class.java)
            startActivity(intent)

        }
    }
}